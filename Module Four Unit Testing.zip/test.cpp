#include "pch.h"

class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

//test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    //checks that collection is empty (starting point)
    ASSERT_TRUE(collection->empty());
    //checks the size is 0 to verify it is empty
    EXPECT_EQ(collection->size(), 0);

    //add entry
    add_entries(1);

    //checks if collection is empty after adding entry
    EXPECT_FALSE(collection->empty());
    //checks that the size is now 1 after the added entry
    ASSERT_EQ(collection->size(), 1);
}

//test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{

    //checks that collection is empty (starting point)
    ASSERT_TRUE(collection->empty());
    //checks the size is 0 to verify it is empty
    EXPECT_EQ(collection->size(), 0);

    //adds 5 entries
    add_entries(5);

    //checks if collection is empty after adding entry
    EXPECT_FALSE(collection->empty());
    //checks that the size is now 5 after the added entry
    ASSERT_EQ(collection->size(), 5);
}

//test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeVerification) {

    //checks that the collection is empty
    ASSERT_TRUE(collection->empty());
    //checks that the empty collection's size is zero
    EXPECT_EQ(collection->size(), 0);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->max_size(), collection->size());

    //add 1 entry
    add_entries(1);
    //checks that the collection's size is now 1
    EXPECT_EQ(collection->size(), 1);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->max_size(), collection->size());

    //clear collection
    collection->clear();
    //add 5 entries
    add_entries(5);
    //checks that the collection's size is now 5
    EXPECT_EQ(collection->size(), 5);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->max_size(), collection->size());

    //clear collection
    collection->clear();
    //add 10 entries
    add_entries(10);
    //checks that the collection's size is now 10
    EXPECT_EQ(collection->size(), 10);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->max_size(), collection->size());
}

//test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityVerification) {

    //checks that the collection is empty
    ASSERT_TRUE(collection->empty());
    //checks that the empty collection's size is zero
    EXPECT_EQ(collection->size(), 0);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->capacity(), collection->size());

    //add 1 entry
    add_entries(1);
    //checks that the collection's size is now 1
    EXPECT_EQ(collection->size(), 1);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->capacity(), collection->size());

    //clear collection
    collection->clear();
    //add 5 entries
    add_entries(5);
    //checks that the collection's size is now 5
    EXPECT_EQ(collection->size(), 5);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->capacity(), collection->size());

    //clear collection
    collection->clear();
    //add 10 entries
    add_entries(10);
    //checks that the collection's size is now 10
    EXPECT_EQ(collection->size(), 10);
    //checks that the collection max size is greater or equal to collection size
    ASSERT_GE(collection->capacity(), collection->size());
}

//test to verify resizing increases the collection
TEST_F(CollectionTest, DoesResizeIncreaseCollection) {

    //checks that the current size of the collection is zero
    ASSERT_EQ(collection->size(), 0);

    //resize the collection to size 24
    collection->resize(24);

    //checks the new size of the collection
    ASSERT_EQ(collection->size(), 24);

}

//test to verify resizing decreases the collection
TEST_F(CollectionTest, DoesResizeDecreaseCollection) {

    //checks that the current size of the collection is zero
    ASSERT_EQ(collection->size(), 0);

    //resize the collection to size 24
    collection->resize(24);

    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 24);

    //resizes collection down to 5
    collection->resize(5);

    //checks the new size of the collection
    ASSERT_EQ(collection->size(), 5);

}

//test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DoesResizeDecreaseCollectionToZero) {

    //checks that the current size of the collection is zero
    ASSERT_EQ(collection->size(), 0);

    //resize the collection to size 24
    collection->resize(24);

    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 24);

    //resizes collection down to 0
    collection->resize(0);

    //checks that the collection is empty again
    EXPECT_TRUE(collection->empty());
    //checks the new size of the collection
    ASSERT_EQ(collection->size(), 0);
}

//test to verify clear erases the collection
TEST_F(CollectionTest, DoesClearEraseTheCollection) {

    //checks that collection is currently empty
    ASSERT_TRUE(collection->empty());
    //checks that the current size of the collection is zero
    EXPECT_EQ(collection->size(), 0);

    //add 10 entries
    add_entries(10);

    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 10);

    //use clear to erase the collection
    collection->clear();

    //checks that the collection is empty again
    ASSERT_TRUE(collection->empty());
    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 0);
}

//test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, DoesEraseBeginEndEraseTheCollection) {

    //checks that collection is currently empty
    ASSERT_TRUE(collection->empty());
    //checks that the current size of the collection is zero
    EXPECT_EQ(collection->size(), 0);

    //add 10 entries
    add_entries(10);

    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 10);

    //use erase(begin end) to erase collection
    collection->erase(collection->begin(), collection->end());

    //checks that the collection is empty again
    ASSERT_TRUE(collection->empty());
    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 0);
}

//test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, DoesReserveIncreaseCapacityNotSize) {

    //checks that the current size of the collection is zero
    ASSERT_EQ(collection->size(), 0);

    //add 1 entry
    add_entries(1);

    //checks the new size of the collection
    EXPECT_EQ(collection->size(), 1);
    //checks the capacity of the collection
    EXPECT_EQ(collection->capacity(), 1);

    collection->reserve(5);

    //check the size
    ASSERT_EQ(collection->size(), 1);
    //check the capacity
    ASSERT_EQ(collection->capacity(), 5);
}

//test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, DoesExceptionGetThrownForOutOfRange) {

    //checks that the current size of the collection is zero
    EXPECT_EQ(collection->size(), 0);

    //add 1 entry
    add_entries(1);

    //checks that the current size of the collection is 1
    EXPECT_EQ(collection->size(), 1);

    //check if exception is thrown
    ASSERT_THROW(collection->at(5), std::out_of_range);
}

//test to check if arithmetic operations change the size of the collections
//Positive Test
TEST_F(CollectionTest, DoArithmeticOperationsChangeCollectionSize) {

    //checks that the current size of the collection is zero
    ASSERT_EQ(collection->size(), 0);

    //add 1 entry
    add_entries(1);

    //check if collection size increased
    EXPECT_EQ(collection->size(), 1);

    //add 5 more entries to collection size
    add_entries(collection->size() + 5);

    //check that collection size has increased
    ASSERT_GE(collection->size(), 6);

    //add 10 times more than current collection size
    add_entries(collection->size() * 10);

    //check that collection size has changed
    ASSERT_GE(collection->size(), 60);
}

//test to ensure a length_error exception is thrown if collections is resized above max_size
//Negative test
TEST_F(CollectionTest, DoesLengthErrorExceptionGetThrownForImproperResize) {

    //checks that the current size of the collection is zero
    EXPECT_EQ(collection->size(), 0);

    //checks if length_error exception is thrown
    ASSERT_THROW(collection->resize(collection->max_size() + 1), std::length_error);
    
    //check to ensure collection is still size 0
    EXPECT_EQ(collection->size(), 0);
}

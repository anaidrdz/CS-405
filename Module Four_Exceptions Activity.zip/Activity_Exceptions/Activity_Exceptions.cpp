#include <iostream>

class custom_Exception : public std::exception {

};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    //throw standard exception created
    throw std::exception("Throwing any standard exception");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    //added a try catch block to wrap do_even_more_custom_application_logic call
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }   

    //catch and display message, exception.what() continues processing
    catch (const std::exception& exception) {
        std::cout << "Custom Application Logic exception: " << exception.what() << std::endl;
    }

    //throw custom exception
    throw custom_Exception();
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //check if denominator is equal to zero
    if (den == 0) {

        //throw exception
        throw std::exception("Cannot divide by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //try catch block to capture the exception thrown by divide
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    
    //catch and display message
    catch (const std::exception& exception) {
        std::cout << "Divide exception: " << exception.what() << std::endl;
    }
}

int main()
{
    //try catch block to handle custom exception, std::exception, and uncaught exception (in order)
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        //call the functions to test their exception handling
        do_division();
        do_custom_application_logic();
    }

    //catch my custom exception and display message to console
    catch (const custom_Exception& exception) {
        std::cout << "Custom exception: " << exception.what() << std::endl;
    }

    //catch the std::exception and display message to console
    catch (const std::exception& exception) {
        std::cout << "std::exception: " << exception.what() << std::endl;
    }

    //catch uncaught exception and display message to console
    catch (...) {
        std::cout << "Uncaught exception: " << std::endl;
    }
}
